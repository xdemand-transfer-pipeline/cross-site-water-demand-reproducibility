"""
Logging utilities.

We keep logging configuration in one place so the rest of the code can do:
    from src.logging_utils import get_logger
    log = get_logger(__name__)
    log.info("hello")
"""
import logging
from typing import Optional

def get_logger(name: Optional[str] = None) -> logging.Logger:
    logger = logging.getLogger(name if name else "water-demand")
    if not logger.handlers:
        # Create a friendly, human-readable formatter
        handler = logging.StreamHandler()
        fmt = "[%(asctime)s] %(levelname)s %(name)s: %(message)s"
        datefmt = "%Y-%m-%d %H:%M:%S"
        handler.setFormatter(logging.Formatter(fmt=fmt, datefmt=datefmt))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger
