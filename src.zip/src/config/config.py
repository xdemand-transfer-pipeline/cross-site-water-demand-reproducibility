"""
Configuration helpers for the cross-site water demand project.

This module centralizes all configuration handling (YAML + CLI overrides) so that
*experiments are reproducible* and *intent is explicit*. It is intentionally verbose:
the goal is to make it easy for a reader to skim and understand what knobs exist
without jumping across files.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Optional
import yaml
import json
from pathlib import Path

@dataclass
class TrainingConfig:
    seed: int = 42
    test_days: int = 14
    horizon: int = 24
    seq_len: int = 48
    epochs: int = 5
    batch_size: int = 64
    learning_rate: float = 1e-3
    model: str = "lightgbm"  # one of: seasonal_naive, lightgbm, lstm
    site: str = "0"

@dataclass
class Paths:
    data_dir: str = "./experiments/synth"
    out_root: str = "./outputs"

@dataclass
class LightGBMParams:
    objective: str = "regression"
    n_estimators: int = 600
    learning_rate: float = 0.05
    num_leaves: int = 31
    subsample: float = 0.9
    colsample_bytree: float = 0.9
    reg_alpha: float = 0.0
    reg_lambda: float = 0.0

@dataclass
class ProjectConfig:
    training: TrainingConfig = field(default_factory=TrainingConfig)
    paths: Paths = field(default_factory=Paths)
    lightgbm: LightGBMParams = field(default_factory=LightGBMParams)

    @staticmethod
    def load(path: Optional[str]) -> "ProjectConfig":
        if path is None:
            return ProjectConfig()
        with open(path, "r") as f:
            data = yaml.safe_load(f) or {}
        # Very explicit mapping for clarity
        return ProjectConfig(
            training=TrainingConfig(**data.get("training", {})),
            paths=Paths(**data.get("paths", {})),
            lightgbm=LightGBMParams(**data.get("lightgbm", {})),
        )

    def dump(self, path: str) -> None:
        """Write current config to YAML (and also a JSON next to it for convenience)."""
        y = {
            "training": asdict(self.training),
            "paths": asdict(self.paths),
            "lightgbm": asdict(self.lightgbm),
        }
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w") as f:
            yaml.safe_dump(y, f, sort_keys=False)
        with open(str(p).replace(".yaml", ".json"), "w") as f:
            json.dump(y, f, indent=2)
