from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Dict, Any, Optional, List
try:
    import lightgbm as lgb
except ImportError as e:
    raise ImportError('lightgbm is required for LightGBM model. Please install lightgbm.') from e

class LightGBMRegressor:
    """A thin wrapper around LGBMRegressor with sensible defaults.

    Why a wrapper? It gives us a stable, explicit interface and a convenient place
    to save artifacts (feature importances), keeping the training logic clean.
    """
    def __init__(self, params: Optional[Dict[str, Any]] = None):
        self.params = params or dict(objective='regression', n_estimators=600, learning_rate=0.05)
        self.model: Optional[lgb.LGBMRegressor] = None
        self.feature_names_: Optional[List[str]] = None

    def fit(self, X: pd.DataFrame, y: np.ndarray):
        self.feature_names_ = list(X.columns)
        self.model = lgb.LGBMRegressor(**self.params)
        self.model.fit(X, y)
        return self

    def predict(self, X: pd.DataFrame):
        return self.model.predict(X)

    def feature_importance(self) -> pd.DataFrame:
        if self.model is None or self.feature_names_ is None:
            raise RuntimeError("Call fit() before feature_importance().")
        imp = self.model.feature_importances_
        return pd.DataFrame({"feature": self.feature_names_, "importance": imp}).sort_values("importance", ascending=False)
