from __future__ import annotations
import torch
import torch.nn as nn
import numpy as np

class LSTMReg(nn.Module):
    """A compact LSTM regressor for univariate sequences.

    This is intentionally small — it trains quickly on CPU for demonstration while
    retaining the familiar interface used in many forecasting papers.
    """
    def __init__(self, input_size=1, hidden_size=64, num_layers=2, dropout=0.1):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=num_layers, batch_first=True, dropout=dropout)
        self.head = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # x: (B, T, 1)
        out, _ = self.lstm(x)
        last = out[:, -1, :]
        return self.head(last).squeeze(-1)

def train_lstm(X, y, epochs=5, lr=1e-3, batch_size=64, device='cpu', early_stop: int | None = None):
    X = torch.tensor(X).unsqueeze(-1)  # (N, T, 1)
    y = torch.tensor(y)
    ds = torch.utils.data.TensorDataset(X, y)
    dl = torch.utils.data.DataLoader(ds, batch_size=batch_size, shuffle=True)
    model = LSTMReg().to(device)
    optim = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    model.train()
    best_loss = float('inf'); patience = 0
    for ep in range(epochs):
        running = 0.0; n = 0
        for xb, yb in dl:
            xb = xb.to(device); yb = yb.to(device)
            pred = model(xb)
            loss = loss_fn(pred, yb)
            optim.zero_grad(); loss.backward(); optim.step()
            running += loss.item()*len(xb); n += len(xb)
        ep_loss = running/max(n,1)
        # Natural comment: early stopping is a pragmatic guard against overfitting/noise.
        if early_stop is not None:
            if ep_loss < best_loss - 1e-6:
                best_loss = ep_loss; patience = 0
            else:
                patience += 1
                if patience >= early_stop:
                    break
    return model

def predict_lstm(model, X):
    with torch.no_grad():
        X = torch.tensor(X).unsqueeze(-1)
        pred = model(X).cpu().numpy()
    return pred
