from __future__ import annotations
import numpy as np

class SeasonalNaive:
    def __init__(self, season_lag: int = 24):
        self.season_lag = season_lag

    def fit(self, X, y):
        return self

    def predict(self, series, horizon: int):
        # series: 1D array of past target values
        hist = np.asarray(series)
        preds = []
        for h in range(1, horizon+1):
            preds.append(hist[-self.season_lag + (h-1)])
        return np.array(preds)
