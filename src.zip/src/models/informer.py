# Placeholder Informer implementation.
# This file documents expected signatures so readers can plug in a reference implementation if desired.
class InformerModel:
    def __init__(self, **kwargs):
        raise NotImplementedError("Informer is not provided in this public release. See README for rationale.")
