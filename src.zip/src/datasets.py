from __future__ import annotations
"""
Dataset helpers and feature builders.

This module is intentionally verbose and richly commented to serve as a didactic,
*self-documenting* reference. A reader should be able to understand the end-to-end
data flow by skimming only this file.
"""
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Dict, Iterable, List

REQUIRED_COLUMNS = ["timestamp", "demand"]

def _validate_columns(df: pd.DataFrame) -> None:
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Input is missing required columns: {missing}. Available: {list(df.columns)}")


def load_site(data_dir: str | Path, site_id: str) -> pd.DataFrame:
    """Load a single site's time series.

    Parameters
    ----------
    data_dir : str or Path
        Directory containing CSVs named like 'site_0.csv'.
    site_id : str
        The site identifier (used in the filename).

    Returns
    -------
    pd.DataFrame
        A dataframe sorted by timestamp with required columns.
    """
    df = pd.read_csv(Path(data_dir)/f"site_{site_id}.csv", parse_dates=['timestamp'])
    df = df.sort_values('timestamp').reset_index(drop=True)
    _validate_columns(df)
    # Natural, pragmatic comment: if your real data includes other signals (pressure,
    # chlorine, pump cycles), keep them here — the LightGBM model can consume them.
    return df


def split_train_test(df: pd.DataFrame, test_days: int = 14) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Time-based split with a *clear wall* between train and test.

    We follow forecasting good practice: the test set is a *suffix* (last N days).
    """
    cutoff = df['timestamp'].max() - pd.Timedelta(days=test_days)
    train = df[df['timestamp'] <= cutoff].copy()
    test  = df[df['timestamp'] >  cutoff].copy()
    if len(test) == 0:
        raise ValueError("Test split is empty — reduce test_days or provide a longer series.")
    return train, test


def build_lag_features(
    df: pd.DataFrame,
    lags: Iterable[int] = (1,2,3,24,25,26,48,49),
    target_col: str = 'demand',
    drop_na: bool = True
) -> pd.DataFrame:
    """Create a small but strong set of lag-based features.

    We intentionally keep this compact and transparent — reviewers can quickly
    see *what goes in* and *why*. Add engineered features here if desired.
    """
    out = df.copy()
    for l in lags:
        out[f'lag_{l}'] = out[target_col].shift(l)
    # Time-of-day and day-of-week are consistently useful in urban demand
    out['hour'] = out['timestamp'].dt.hour
    out['dow']  = out['timestamp'].dt.dayofweek

    if drop_na:
        out = out.dropna().reset_index(drop=True)
    return out


def make_sequences(df: pd.DataFrame, seq_len: int, target_h: int, target_col='demand'):
    """Turn a univariate series into (X, y) sequences for neural models.

    Notes
    -----
    *X shape*: (N, seq_len) -> will be expanded to (N, seq_len, 1) later.
    *y shape*: (N,)
    """
    X, y, ts = [], [], []
    values = df[target_col].values.astype('float32')
    for i in range(len(values) - seq_len - target_h + 1):
        X.append(values[i:i+seq_len])
        y.append(values[i+seq_len+target_h-1])
        ts.append(df['timestamp'].iloc[i+seq_len+target_h-1])
    X = np.stack(X)
    y = np.stack(y).astype('float32')
    return X, y, ts
