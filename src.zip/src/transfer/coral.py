from __future__ import annotations
import numpy as np

def _cov(x: np.ndarray):
    x = x - x.mean(axis=0, keepdims=True)
    return (x.T @ x) / (x.shape[0] - 1)

def coral_align(Xs: np.ndarray, Xt: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    """CORAL: Align source features to target covariance.
    Returns transformed source features with target covariance.
    """
    Cs = _cov(Xs) + eps * np.eye(Xs.shape[1])
    Ct = _cov(Xt) + eps * np.eye(Xt.shape[1])
    # whitening + re-coloring
    from scipy.linalg import fractional_matrix_power
    As = fractional_matrix_power(Cs, -0.5)
    At = fractional_matrix_power(Ct, 0.5)
    Xs_c = (Xs - Xs.mean(0)) @ As @ At + Xt.mean(0)
    return Xs_c
