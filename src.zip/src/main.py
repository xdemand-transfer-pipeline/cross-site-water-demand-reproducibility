from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
import numpy as np

from src.datasets import load_site, split_train_test, build_lag_features, make_sequences
from src.evaluation import metrics, plot_residual_acf, qq_plot
from src.plots import line_plot
from src.utils import set_seed
from src.logging_utils import get_logger
from src.config.config import ProjectConfig

from src.models.seasonal_naive import SeasonalNaive
from src.models.lightgbm_model import LightGBMRegressor
from src.models.lstm import train_lstm, predict_lstm

log = get_logger(__name__)

def run_seasonal_naive(df, horizon, out_dir):
    train, test = split_train_test(df)
    preds, truth, ts = [], [], []
    series = train['demand'].tolist()
    model = SeasonalNaive(season_lag=24)
    for i in range(len(test)):
        pred = model.predict(series, horizon=1)[0]
        preds.append(pred)
        truth.append(test['demand'].iloc[i])
        ts.append(test['timestamp'].iloc[i])
        series.append(test['demand'].iloc[i])
    m = metrics(truth, preds)
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    line_plot(ts, truth, preds, Path(out_dir)/'pred_vs_true.png')
    resid = np.array(truth)-np.array(preds)
    plot_residual_acf(resid, max_lag=48, out_path=Path(out_dir)/'residual_acf.png')
    qq_plot(resid, out_path=Path(out_dir)/'residual_qq.png')
    pd.Series(m).to_json(Path(out_dir)/'metrics.json')
    log.info('SeasonalNaive metrics: %s', m)

def run_lightgbm(df, out_dir, lgbm_params: dict):
    train, test = split_train_test(df)
    tr = build_lag_features(train)
    te = build_lag_features(pd.concat([train.tail(60), test], ignore_index=True)).iloc[60:]
    ytr = tr['demand'].values; Xtr = tr.drop(columns=['timestamp','demand'])
    yte = te['demand'].values; Xte = te.drop(columns=['timestamp','demand'])
    model = LightGBMRegressor(params=lgbm_params)
    model.fit(Xtr, ytr)
    preds = model.predict(Xte)
    m = metrics(yte, preds)
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    line_plot(te['timestamp'].values, yte, preds, out/'pred_vs_true.png')
    resid = yte - preds
    plot_residual_acf(resid, max_lag=48, out_path=out/'residual_acf.png')
    qq_plot(resid, out_path=out/'residual_qq.png')
    pd.Series(m).to_json(out/'metrics.json')
    # Save feature importances (a reviewer favorite)
    fi = model.feature_importance()
    fi.to_csv(out/'feature_importance.csv', index=False)
    log.info('LightGBM metrics: %s', m)

def run_lstm(df, seq_len, epochs, out_dir, lr: float, batch: int):
    train, test = split_train_test(df)
    full = pd.concat([train.tail(seq_len+48), test], ignore_index=True)
    X, y, ts = make_sequences(full, seq_len=seq_len, target_h=1)
    n_tr = len(make_sequences(train, seq_len=seq_len, target_h=1)[0])
    Xtr, ytr = X[:n_tr], y[:n_tr]
    Xte, yte, ts_te = X[n_tr:], y[n_tr:], ts[n_tr:]
    model = train_lstm(Xtr, ytr, epochs=epochs, lr=lr, batch_size=batch, early_stop=3)
    preds = predict_lstm(model, Xte)
    m = metrics(yte, preds)
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    line_plot(ts_te, yte, preds, out/'pred_vs_true.png')
    resid = yte - preds
    plot_residual_acf(resid, max_lag=48, out_path=out/'residual_acf.png')
    qq_plot(resid, out_path=out/'residual_qq.png')
    pd.Series(m).to_json(out/'metrics.json')
    log.info('LSTM metrics: %s', m)

def main():
    ap = argparse.ArgumentParser(description="Run cross-site water demand experiments (public release)")
    ap.add_argument('--config', type=str, default=None, help='Optional YAML config file')
    ap.add_argument('--data_dir', type=str, default=None, help='Override: directory with site_*.csv')
    ap.add_argument('--site', type=str, default=None, help='Override: site id (e.g., 0)')
    ap.add_argument('--model', type=str, choices=['seasonal_naive','lightgbm','lstm'], default=None)
    ap.add_argument('--horizon', type=int, default=None)
    ap.add_argument('--seq_len', type=int, default=None)
    ap.add_argument('--epochs', type=int, default=None)
    ap.add_argument('--out_root', type=str, default=None)
    args = ap.parse_args()

    cfg = ProjectConfig.load(args.config)
    # CLI overrides (explicit and transparent)
    if args.data_dir is not None: cfg.paths.data_dir = args.data_dir
    if args.site is not None: cfg.training.site = args.site
    if args.model is not None: cfg.training.model = args.model
    if args.horizon is not None: cfg.training.horizon = args.horizon
    if args.seq_len is not None: cfg.training.seq_len = args.seq_len
    if args.epochs is not None: cfg.training.epochs = args.epochs
    if args.out_root is not None: cfg.paths.out_root = args.out_root

    set_seed(cfg.training.seed)
    df = load_site(cfg.paths.data_dir, cfg.training.site)
    out_dir = Path(cfg.paths.out_root)/f"{cfg.training.model}_site{cfg.training.site}"

    if cfg.training.model == 'seasonal_naive':
        run_seasonal_naive(df, cfg.training.horizon, out_dir)
    elif cfg.training.model == 'lightgbm':
        run_lightgbm(df, out_dir, lgbm_params=dict(
            objective=cfg.lightgbm.objective,
            n_estimators=cfg.lightgbm.n_estimators,
            learning_rate=cfg.lightgbm.learning_rate,
            num_leaves=cfg.lightgbm.num_leaves,
            subsample=cfg.lightgbm.subsample,
            colsample_bytree=cfg.lightgbm.colsample_bytree,
            reg_alpha=cfg.lightgbm.reg_alpha,
            reg_lambda=cfg.lightgbm.reg_lambda,
        ))
    elif cfg.training.model == 'lstm':
        run_lstm(df, seq_len=cfg.training.seq_len, epochs=cfg.training.epochs,
                 out_dir=out_dir, lr=cfg.training.learning_rate, batch=cfg.training.batch_size)

if __name__ == '__main__':
    main()
