from __future__ import annotations
import numpy as np
import pandas as pd
from pathlib import Path
import argparse

def synth_site(seed, start='2022-01-01', periods=24*120, freq='H', level=100.0, shift=0.0):
    rng = np.random.default_rng(seed)
    ts = pd.date_range(start=start, periods=periods, freq=freq)
    hour = ts.hour
    dow = ts.dayofweek
    diurnal = 10*np.sin(2*np.pi*hour/24) + 5*np.sin(2*np.pi*hour/12)
    weekly = 3*np.where(dow<5, 1.0, 0.7)
    noise = rng.normal(0, 2, size=periods)
    demand = level + shift + diurnal + weekly + noise
    pump = (hour%6==0).astype(float)  # crude operational signal
    return pd.DataFrame({'timestamp': ts, 'demand': demand, 'pump': pump})

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=str, required=True)
    ap.add_argument('--n_days', type=int, default=120)
    ap.add_argument('--n_sites', type=int, default=3)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    periods = 24*args.n_days
    for s in range(args.n_sites):
        df = synth_site(seed=42+s, periods=periods, level=100+5*s, shift=3*s)
        df.to_csv(out/f'site_{s}.csv', index=False)
    print(f'Wrote synthetic data to {out}')

if __name__ == '__main__':
    main()
