from __future__ import annotations
"""
Evaluation helpers: classic regression metrics and simple-but-useful diagnostics.

Why keep it simple? Because *clarity beats cleverness* for reproducibility.
We prefer well-understood quantities (MSE, RMSE, MAE) and visual checks
(ACF, QQ) that match the narrative in the manuscript.
"""
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Tuple
from pathlib import Path
from statsmodels.tsa.stattools import acf
from scipy import stats

def metrics(y_true, y_pred) -> Dict[str, float]:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    mse = float(np.mean((y_true - y_pred)**2))
    rmse = float(np.sqrt(mse))
    mae = float(np.mean(np.abs(y_true - y_pred)))
    return {'MSE': mse, 'RMSE': rmse, 'MAE': mae}

def plot_residual_acf(residuals, max_lag: int, out_path: str | Path):
    r = acf(residuals, nlags=max_lag, fft=True)
    plt.figure()
    plt.stem(range(len(r)), r, use_line_collection=True)
    plt.xlabel('Lag')
    plt.ylabel('ACF')
    plt.title('Residual autocorrelation')
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()

def qq_plot(residuals, out_path: str | Path):
    """A quick sanity check for normality assumptions used in confidence reporting."""
    plt.figure()
    stats.probplot(residuals, dist="norm", plot=plt)
    plt.title("Residual QQ-plot")
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()
