import matplotlib.pyplot as plt
from pathlib import Path

def line_plot(ts, y_true, y_pred, out_path):
    plt.figure()
    plt.plot(ts, y_true, label='True')
    plt.plot(ts, y_pred, label='Pred')
    plt.xlabel('Time')
    plt.ylabel('Demand')
    plt.legend()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()
